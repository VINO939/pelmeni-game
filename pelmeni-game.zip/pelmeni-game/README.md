# Лови пельмени!

Мини-игра на HTML + JS. Готова к публикации через GitHub Pages.

## 📦 Как использовать

1. Загрузите этот проект на GitHub
2. Включите GitHub Pages через Settings > Pages
3. Наслаждайтесь игрой по адресу `https://ВАШ_НИК.github.io/pelmeni-game/`
